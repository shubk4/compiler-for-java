#include<bits/stdc++.h>

using namespace std;

extern int cnt;

struct quadruple{
    string op;
    string arg1;
    string arg2;
    string res;
    int idx;
};

// extern map<int , string> gotoLabels;

// void emit(qid, qid , qid , qid , int );
// void backpatch(vector<int>& , int);
// qid newtemp(string );
// int assign_exp(string op, string type, string type1,string type2, qid arg1, qid arg2);
// void casepatch(vector<int>& bplist, qid target);
// void print3AC_code();
// void backpatch_rem();
