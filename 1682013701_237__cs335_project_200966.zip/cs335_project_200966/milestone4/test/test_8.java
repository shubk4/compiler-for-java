public class CallingMethodsInSameClass
{
	public static void main(int[] args) {
	
	}

	public static int printOne(int x) {
		System.out.println("Hello World");
		int a;
		b = new int[10];
		a++;
		return a;
	}

	public static void printTwo() {
		
	}
}
