
public class CodesCracker
{
   public static void main(String[] args)
   {
      int n, i, num=0, sum=0;

      System.out.println("Enter the Value of n: ");
      System.out.println("Enter  Numbers: ");


      System.out.println(sum);
   }
}
