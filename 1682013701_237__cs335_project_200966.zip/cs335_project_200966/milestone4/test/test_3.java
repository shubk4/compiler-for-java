
class dimple{
    int i = 0;
    public static void main(String[] args){
     System.out.println("Hello Java");
    }
    public static void dimple(String[] arg1){
     System.out.println("Hello world");
     int j;
     main();
    }
    
}