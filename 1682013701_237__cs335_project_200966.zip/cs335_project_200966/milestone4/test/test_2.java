public class Largest {

    public static void main(String[] args) {

        float n1 = 4.5, n2 = 3.9, n3 = 2.5;

        if( n1 >= n2 && n1 >= n3){
            System.out.println(n1);
            System.out.println(" is the largest number.");}

        else if (n2 >= n1 && n2 >= n3){
            System.out.println(n2);
            System.out.println(" is the largest number.");}


        else{
            System.out.println(n3);
            System.out.println(" is the largest number.");}

    }
}
