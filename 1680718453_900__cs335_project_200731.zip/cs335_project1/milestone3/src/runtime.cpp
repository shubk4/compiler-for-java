#include<bits/stdc++.h>
#include"runtime.h"
using namespace std;
void memoryAlloc(){
}
int main(){
    memoryAlloc();
    return 0;
}