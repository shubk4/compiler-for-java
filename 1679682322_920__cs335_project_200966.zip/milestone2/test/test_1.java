class Main {

	public static void main(String[] args) {

	  int first = 10;
	  int second = 20;

	  // add two numbers
	  int sum = first + second;
	  System.out.println( sum);
	}
  }
